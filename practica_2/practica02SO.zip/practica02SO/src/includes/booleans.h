/*
 * booleans.h
 *
 *  Author: Alaín Chevanier
 */

#ifndef BOOLEANS_H_
#define BOOLEANS_H_

#define TRUE    1
#define FALSE    0

#endif /* BOOLEANS_H_ */
